package LaboBOTest;

import org.testng.Assert;
import org.testng.annotations.Test;

import PageActions.Characteristicspage;
import PageActions.Formulapage;
import PageActions.Loginpage;
import PageActions.Volumepage;

public class LaboTest extends Basetest {

	@Test
	public void login()
	
	{		
		Loginpage loginpage= goToURL();
	    loginpage.login();
	}
	
	@Test
	public void saveCharacteristics() throws InterruptedException
	{
		Loginpage loginpage= goToURL();
		Characteristicspage Characteristicspage=loginpage.login();
		Characteristicspage.checkHomePage();
		Characteristicspage.selectCharacteristics();
		Assert.assertEquals(Characteristicspage.saveCentrale(), successMessage);
		Assert.assertEquals(Characteristicspage.saveMultipleCentrale(), popupheader);
	}
	
	@Test
	public void saveFormula() throws InterruptedException
	{
		Loginpage loginpage = goToFormulaLink();
		Formulapage formulapage = loginpage.formulalogin();
		Assert.assertEquals(formulapage.formulaSelection(), formulasuccessMessage);
	}
	
	@Test
	public void saveVolume() throws InterruptedException
	{
		saveCharacteristics();
		Volumepage volumepage = new Volumepage(driver);
		volumepage.saveVolume();
	}
}
